function enviarForm(nombre,apellidos,email,pass){
    let mensajeFinal = "A continuación te indico los campos a rellenar\n";
    let nombreComprobado = comprobarNombre(nombre);
    let apellidosComprobado = comprobarApellidos(apellidos);
    let emailComprobado = comprobarEmail(email);
    let passComprobado = comprobarPass(pass);
    


if (nombreComprobado==true){mensajeFinal+="Te falta por incluir el Nombre\n";}
if (apellidosComprobado==true){mensajeFinal+="Te falta por incluir el Apellidos\n";}
if (emailComprobado==true){mensajeFinal+="Te falta por incluir el Email\n";}
if (passComprobado==true){mensajeFinal+="Te falta por incluir la Contaseña\n";}
if(nombreComprobado==false && apellidosComprobado==false && emailComprobado==false && passComprobado==false ){mensajeFinal=("Gracias por contactar con nosotros "+nombre.toUpperCase() +
    " \n Leeremos su mensaje y le responderemos lo antes posible");
}
return alert(mensajeFinal);
console.log(mensajeFinal);
}

function comprobarNombre(nombre){
    let estado=false;
    if (nombre==""){
        estado=true;
    }
    return estado;
}

function comprobarApellidos(apellidos){
    let estado=false;
    if (apellidos==""){
        estado=true;
    }
    return estado;
}

function comprobarEmail(email){
    let estado=false;
    if (email==""){
        estado=true;
    }
    return estado;
}

function comprobarPass(pass){
    let estado=false;
    if (pass==""){
        estado=true;
    }
    return estado;
}