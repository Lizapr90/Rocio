let gastosAlojamiento = parseFloat(prompt("Introduce los gastos de alojamiento"));
let gastosAlimentacion = parseFloat(prompt("Introduce los gastos de alimentación"));
let gastosEntretenimiento = parseFloat(prompt("Introduce los gastos de entretenimiento"));

let gastosViaje = gastosAlojamiento+gastosAlimentacion+gastosEntretenimiento;
  
alert("El coste total de tu viaje es :" + gastosViaje);


